﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBlockVert : MonoBehaviour
{
    public Vector3 moveUp;
    public Vector3 moveDown;
    public float x;
    public float y;
	// Use this for initialization
	void Start ()
    {
        x = transform.position.x;
        y = transform.position.y;
    }
	
	// Update is called once per frame
	void Update ()
    {
        x = transform.position.x;
        y = transform.position.y;
        if (y < 3.0f)
        {
            y = y + 0.1f;
            moveUp = new Vector3(x, y, 0.0f);
            transform.position = moveUp;
        }

        if (y >= 3.0f)
        {
            y = -4.0f;
            moveUp = new Vector3(x, y, 0.0f);
            transform.position = moveUp;
        }
    }
}
