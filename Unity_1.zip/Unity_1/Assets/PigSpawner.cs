﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PigSpawner : MonoBehaviour
{
    public GameObject temp;
    public Vector3 fallpig;
    public Vector3 copypig;
    public float x;
    public float y;
    public float z;
    public float b;
    public float a;
    // Use this for initialization
    void Start()
    {
        a = 0;
    }

    // Update is called once per frame
    void Update()
    {
        x = Random.Range(-5, 5);
        b = x - 3.0f;
    }

    void OnCollisionEnter2D()
    {
        y = 3.5f;
        z = 0.0f;
        x = Random.Range(-5, 5);
        fallpig = new Vector3(x, y, 0.0f);
        transform.position = fallpig;
        b = x - 2.5f;
        if (a < 1)
        {
            copypig = new Vector3(b,y,z);
            Instantiate(temp, copypig, transform.rotation);
            a = a + 1;
            z = z + 1;
        }
        
    }
}
