﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VolleyHan : MonoBehaviour
{
    public GameObject temp;
    public Vector3 fallpig;
    public Vector3 horiz;
    public float y;
    public float x;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("a"))
        {
            x = x - 0.5f;
            horiz = new Vector3(x, -3.0f, 0.0f);
            transform.position = horiz;
        }

        if (Input.GetKey("d"))
        {
            x = x + 0.5f;
            horiz = new Vector3(x, y-3.0f, 0.0f);
            transform.position = horiz;
        }


    }

}