﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGame : MonoBehaviour
{
    public Vector3 end;
    public Vector3 handEnd;
    public float x;
    public float y;
    public float z;
    // Use this for initialization
    void Start()
    {
        z = -5;
        x = transform.position.x;
        y = transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnCollisionStay2D(Collision2D Coll)
    {
        handEnd = new Vector3(x,y,z);
        transform.position = handEnd;
    }

    public void GenericButton()
    {
        end = new Vector3(x, y+300, z);
        transform.position = end;
    }
}

