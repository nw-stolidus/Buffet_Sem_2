﻿using UnityEngine;
using System.Collections;
public class RandomCode : MonoBehaviour
{
    public Vector3 boar;
    public float x;
    public float y;
    void Start()
    {
        x = Random.Range (-10, 10);
        y = Random.Range(-10, 10);
        boar = new Vector3(x, y, 0.0f);
        transform.position = boar;
    }
    void Update()
    {
        x = Random.Range(-10, 10);
        y = Random.Range(-10, 10);
        boar = new Vector3(x, y, 0.0f);
        transform.position = boar;
    }
}



