﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunnerCode : MonoBehaviour
{
    public Vector3 horiz;
    public Vector3 vert;
    public float y;
    public float x;
    // Use this for initialization
    void Start()
    {
        print("Dance");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("a"))
        {
            x = x - 0.5f;
            horiz = new Vector3(x, y, 0.0f);
            transform.position = horiz;
        }

        if (Input.GetKey("d"))
        {
            x = x + 0.5f;
            horiz = new Vector3(x, y, 0.0f);
            transform.position = horiz;
        }

        if (Input.GetKey("w"))
        {
            y = y + 0.5f;
            vert = new Vector3(x, y, 0.0f);
            transform.position = vert;
        }

        if (Input.GetKey("s"))
        {
            y = y - 0.5f;
            vert = new Vector3(x, y, 0.0f);
            transform.position = vert;
        }


    }
}