﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AroundWorld : MonoBehaviour {
    public float x;
    public float y;
    public float a;
    public Vector3 world;
	// Use this for initialization
	void Start () {
        y = 2.0f;
        x = 15.0f;
        a = 0.1f;
	}
	
	// Update is called once per frame
	void Update () {
        x = x - a;
        world = new Vector3(x,y,0.0f);
        transform.position = world;

        if (Input.GetKey("1"))
        {
            a = 0.1f;
        }

        if (Input.GetKey("2"))
        {
            a = 0.33f;
        }

        if (Input.GetKey("3"))
        {
            a = 0.66f;
        }

        if (x <= -16.0f)
        {
            x = 16.0f;
        }
	}
}
