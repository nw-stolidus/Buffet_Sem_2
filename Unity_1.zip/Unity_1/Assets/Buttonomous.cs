﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buttonomous : MonoBehaviour {
    public Vector3 start;
    public float z;
	// Use this for initialization
	void Start () {
        z = -11.0f;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void GenericButton () {
        start = new Vector3(-300.0f, 300.0f, z);
        transform.position = start;
    }
}
