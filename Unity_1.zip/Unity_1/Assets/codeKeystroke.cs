﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class codeKeystroke : MonoBehaviour {
    public Vector3 horiz;
    public Vector3 vert;
    public float x;
    public float y;
	// Use this for initialization
	void Start () {
        print("Dance");
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey("d"))
        {
            x = x - 1;
            horiz = new Vector3(x, y, 0.0f);
            transform.position = horiz;
        }

        if (Input.GetKey("a"))
        {
            x = x + 1;
            horiz = new Vector3(x, y, 0.0f);
            transform.position = horiz;
        }

        if (Input.GetKey("w"))
        {
            y = y + 1;
            vert = new Vector3(x, y, 0.0f);
            transform.position = vert;
        }

        if (Input.GetKey("s"))
        {
            y = y - 1;
            vert = new Vector3(x, y, 0.0f);
            transform.position = vert;
        }
    

    }
}
