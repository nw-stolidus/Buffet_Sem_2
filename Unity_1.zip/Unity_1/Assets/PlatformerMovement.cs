﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformerMovement : MonoBehaviour
{
    public Vector3 mobe;
    public float y;
    public float x;
    // Use this for initialization
    void Start()
    {
        x = transform.position.x;
        y = transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        x = transform.position.x;
        y = transform.position.y;
        if (Input.GetKey("a"))
        {
            x = x - 0.3f;
            mobe = new Vector3(x, y, 0.0f);
            transform.position = mobe;
        }

        if (Input.GetKey("d"))
        {
            x = x + 0.3f;
            mobe = new Vector3(x, y, 0.0f);
            transform.position = mobe;
        }
    }

    void OnCollisionStay2D(Collision2D Coll)
    {
        x = transform.position.x;
        y = transform.position.y;
        if (Input.GetKey("w"))
        {
            for (var i = 0; i < 4; i++)
            {
                y = y + 0.5f;
                mobe = new Vector3(x, y, 0.0f);
                transform.position = mobe;
            }
        }
        
        if (Input.GetKey("space"))
        {
            y = y + 2.0f;
            mobe = new Vector3(x, y, 0.0f);
            transform.position = mobe;
        }

    }
}
