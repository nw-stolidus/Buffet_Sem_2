﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlappyPig : MonoBehaviour
{
    public Vector3 vert;
    public float y;
    public float x;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("w"))
        {
            y = y + 0.3f;
            vert = new Vector3(-3.0f, y, 0.0f);
            transform.position = vert;
        }

        if (Input.GetKey("s"))
        {
            y = y - 0.3f;
            vert = new Vector3(-3.0f, y, 0.0f);
            transform.position = vert;
        }
    }

    void OnCollisionEnter2D()
    {
        print("You've hit a wall.");
    }
}