﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TagCode : MonoBehaviour
{
    public Vector3 mover;
    public float x;
    public float y;
    // Use this for initialization
    void Start()
    {
        print("Dance");
    }

    // Update is called once per frame
    void Update()
    {
            x = Random.Range(0.0f, 1.0f);
            y = Random.Range(0.0f, 1.0f);
            mover = new Vector3(x, y, 0.0f);
            transform.position = mover;
    }
}