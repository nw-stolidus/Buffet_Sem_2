﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BullsSpawn : MonoBehaviour
{
    public Vector3 charge;
    public float y;
    public float x;
    public float a;
    public float b;
    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        y = Random.Range(0, 3);
        a = Random.Range(-3, 3);
        x = x - 0.1f;
        charge = new Vector3(x, -2.5f, 0.0f);
        transform.position = charge;

        if (x <= -16.0f)
        {
            x = 18.0f;
        }

    }
}